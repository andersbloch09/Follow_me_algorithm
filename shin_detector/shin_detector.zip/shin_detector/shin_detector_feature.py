import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from sensor_msgs.msg import LaserScan
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np
import math
import cv2

#------------CLASSES----------------
class LIDARsubscriber(Node):
    def __init__(self):
        super().__init__("LIDAR_subscriber")
        self.subscription = self.create_subscription(
            LaserScan,
            "/scan",
            self.listener_callback,
            QoSProfile(depth=10,reliability=ReliabilityPolicy.BEST_EFFORT))
        self.subscription
    
    def listener_callback(self,msg:LaserScan):
        self.dist = msg.ranges

#-----------FUNCTIONS---------------
def genCluster(subscriber):
    rclpy.spin_once(subscriber)
    points = np.asarray(subscriber.dist)
    for i in range(len(points)):
        vectorArrX[i]=np.cos(np.deg2rad(i))*points[i]
        vectorArrY[i]=np.sin(np.deg2rad(i))*points[i]
    
    coord = tuple(zip(vectorArrX,vectorArrY))
    global db
    db = DBSCAN(eps=0.05, min_samples=5,).fit(coord)

def getFeatures(clust_x, clust_y, clustersize):

            x_mean = sum(clust_x)/clustersize
            y_mean = sum(clust_y)/clustersize

            clust_x_sorted = np.sort(clust_x)
            clust_y_sorted = np.sort(clust_y)
            x_median = np.median(clust_x_sorted)
            y_median = np.median(clust_y_sorted)

            sum_std_diff = sum_med_diff = 0
            for i in range(clustersize):
                sum_std_diff += pow(clust_x[i]-x_mean, 2) + pow(clust_y[i]-y_mean, 2)
                sum_med_diff += math.sqrt(pow(clust_x[i]-x_median, 2)+pow(clust_y[i] - y_median, 2))

            std = math.sqrt(1/(clustersize-1)*sum_std_diff)
            avg_med_dev = sum_med_diff / clustersize

            #122

            width = math.sqrt(pow(clust_x[0]-clust_x[-1], 2) + pow(clust_y[0]-clust_y[-1],2))  #125 - Width

            points2=np.vstack((clust_x,clust_y))
            # print('ff',points2.shape)
            points2=np.transpose(points2)

            # print('ff',points2.shape)

            W = np.zeros((2,2), np.float64)
            w = np.zeros((2,2), np.float64)
            U = np.zeros((clustersize, 2), np.float64)

            V = np.zeros((2,2), np.float64)

            w,u,vt=cv2.SVDecomp(points2,W,U,V)
            # print('ww',w,W)
            rot_points = np.zeros((clustersize,2), np.float64)

            W[0,0]=w[0]
            W[1,1]=w[1]
            rot_points = np.matmul(u,W)
            # print(w)
            # print(u)
            # print(vt)
            # print(rot_points.shape)

            linearity=0
            for i in range(clustersize):
                linearity += pow(rot_points[i, 1], 2)


            #Circularity
            A = np.zeros((clustersize,3), np.float64)
            B = np.zeros((clustersize,1), np.float64)


            for i in range(clustersize):
                A[i,0]=-2.0 * clust_x[i]
                A[i,1]=-2.0 * clust_y[i]
                A[i,2]=1
                B[i,0]=math.pow(clust_x[i], 2)-math.pow(clust_y[i], 2)

            sol = np.zeros((3,1),np.float64)
            cv2.solve(A, B, sol, cv2.DECOMP_SVD)

            xc = sol[0,0]
            yc = sol[1,0]
            rc = math.sqrt(pow(xc, 2)+pow(yc, 2)) - sol[2,0]


            circularity = 0
            for i in range(clustersize):
                circularity += pow(rc - math.sqrt(pow(xc - clust_x[i], 2) + pow(yc-clust_y[i], 2)), 2)


            radius = rc #Radius


            features=[clustersize, std, avg_med_dev, width, linearity, circularity,
                                radius]
            np.savetxt("features",np.column_stack(features),fmt=('%.5f'))

def main(args=None):
    rclpy.init(args=args)

    #Make subscriber and lists for x and y coordinates of point cloud
    lidar_subscriber = LIDARsubscriber()
    global vectorArrX
    global vectorArrY
    vectorArrX = np.zeros(40)
    vectorArrY = np.zeros(40)
    #Generate the first clustered data, for reference in the loop.
    genCluster(lidar_subscriber)

    while(1):
        rclpy.spin_once(lidar_subscriber)
        points = np.asarray(lidar_subscriber.dist)
        
        for i in range(40):
            vectorArrX[i]=np.cos(np.deg2rad(i))*points[i]
            vectorArrY[i]=np.sin(np.deg2rad(i))*points[i]

        coord = tuple(zip(vectorArrX,vectorArrY))
        X = StandardScaler().fit_transform(coord)
        
        
        db = DBSCAN(eps=0.05, min_samples=5).fit(coord)
        labels = db.labels_
        print(labels)

        # Number of clusters in labels, ignoring noise if present.
        n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
        n_noise_ = list(labels).count(-1)

        print("Estimated number of clusters: %d" % n_clusters_)
        print("Estimated number of noise points: %d" % n_noise_)
            
        #-----------------
        unique_labels = set(labels)

        print(f"Labels: {labels}")
        print(f"Components: {db.components_}")
        print(f"Core Samples: {db.core_sample_indices_}")
        print(f"N_features: {db.n_features_in_}")


    
    lidar_subscriber.destroy_node()
    rclpy.shutdown()

if __name__=="__main__":
    main()
